# A Particle Swarm Based Algorithm for Continuous Distributed Constraint Optimization Problems
Papers: 
1. <https://arxiv.org/abs/2010.10192>
2. <https://ojs.aaai.org//index.php/AAAI/article/view/6198>
